# Websocket library for OCaml

# Installation

```
make
jbuilder install
```