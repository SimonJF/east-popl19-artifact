let () =
  Printf.printf "%d\n" [%omp_test]
