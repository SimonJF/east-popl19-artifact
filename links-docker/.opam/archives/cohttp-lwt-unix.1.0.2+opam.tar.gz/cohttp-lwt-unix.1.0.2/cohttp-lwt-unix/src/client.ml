
include Cohttp_lwt.Make_client(Io)(Net)

let custom_ctx = Net.init
