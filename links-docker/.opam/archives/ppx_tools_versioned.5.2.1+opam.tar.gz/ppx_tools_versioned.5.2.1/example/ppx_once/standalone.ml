open Migrate_parsetree

(* To run as a standalone binary, run the registered drivers *)
let () = Driver.run_main ()
