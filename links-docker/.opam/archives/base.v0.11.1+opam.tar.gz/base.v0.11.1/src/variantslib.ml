(** This module is for use by ppx_variants_conv, and is thus not in the interface of
    Base. *)
module Variant = Variant
