open! Import


include Hashable_intf
