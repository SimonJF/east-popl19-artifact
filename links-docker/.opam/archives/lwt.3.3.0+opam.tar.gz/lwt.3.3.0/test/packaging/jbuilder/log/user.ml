let () =
  Lwt_log.default |> ignore
