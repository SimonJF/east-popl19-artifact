* change version number in opam
* change version number in pkg/build
* edit CHANGES
* add a tag