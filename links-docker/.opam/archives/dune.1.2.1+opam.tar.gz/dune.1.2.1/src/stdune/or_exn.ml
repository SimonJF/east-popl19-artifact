type 'a t = ('a, exn) Result.t
