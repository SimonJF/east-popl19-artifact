type t = float

let to_string = string_of_float
