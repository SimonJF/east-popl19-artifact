
let build_cm _ ~js_of_ocaml:_ ~src:_ ~target:_ = []

let build_exe _ ~js_of_ocaml:_ ~src:_ = []

let setup_separate_compilation_rules _ _ = ()

let standard _ = []
