let library_path    = Some []
let library_destdir = None
