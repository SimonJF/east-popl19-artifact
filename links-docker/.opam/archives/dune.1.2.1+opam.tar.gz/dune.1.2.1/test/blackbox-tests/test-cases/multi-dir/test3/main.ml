let () = print_endline (Foo.x () ^ Foo.y ())
