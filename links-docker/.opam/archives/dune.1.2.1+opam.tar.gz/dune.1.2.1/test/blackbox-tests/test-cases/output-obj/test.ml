let () =
  Printf.printf "OK: %s\n%!" (String.concat " " (Array.to_list Sys.argv))
