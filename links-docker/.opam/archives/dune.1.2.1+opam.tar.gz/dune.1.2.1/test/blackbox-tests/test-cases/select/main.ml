print_endline Bar.message;;
print_endline Foo.message;;
