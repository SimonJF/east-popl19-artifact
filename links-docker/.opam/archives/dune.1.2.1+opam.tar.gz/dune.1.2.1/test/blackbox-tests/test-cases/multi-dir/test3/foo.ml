external x : unit -> string = "dune_test_x"
external y : unit -> string = "dune_test_y"
