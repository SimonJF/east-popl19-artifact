#include <stdlib.h>
#include <stdio.h>
void jsPrint () { fprintf(stderr, "Unimplemented Javascript primitive myPrint!\n"); exit(1); }
