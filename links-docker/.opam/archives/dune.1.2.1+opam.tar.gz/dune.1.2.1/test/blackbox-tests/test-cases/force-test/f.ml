
let () = print_endline "Foo Bar"
