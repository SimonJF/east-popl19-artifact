
external q : unit -> int = "ocaml_question"
