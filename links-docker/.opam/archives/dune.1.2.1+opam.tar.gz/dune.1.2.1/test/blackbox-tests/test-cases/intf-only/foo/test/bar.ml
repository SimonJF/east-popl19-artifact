module X = Foo.T

let x = X.A

include Foo.T
