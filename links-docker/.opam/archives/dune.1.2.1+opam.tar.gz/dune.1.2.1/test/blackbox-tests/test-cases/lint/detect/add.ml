let () = Printf.printf "%d\n" @@ 1 + 2
