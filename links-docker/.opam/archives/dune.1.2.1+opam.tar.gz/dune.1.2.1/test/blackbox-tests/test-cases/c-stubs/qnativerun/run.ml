print_int (Q.q ());;
