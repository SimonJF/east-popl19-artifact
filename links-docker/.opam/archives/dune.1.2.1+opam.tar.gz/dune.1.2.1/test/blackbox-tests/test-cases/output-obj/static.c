#include <caml/mlvalues.h>
#include <caml/alloc.h>
#include <caml/callback.h>
#include <caml/memory.h>

int main(int argc, char ** argv){

  caml_startup(argv);
  return 0;
}
