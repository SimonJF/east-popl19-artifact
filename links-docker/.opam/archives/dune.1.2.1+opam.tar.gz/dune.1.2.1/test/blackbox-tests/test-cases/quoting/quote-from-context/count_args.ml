
let () =
  Printf.printf "Number of args: %d\n" (Array.length Sys.argv - 1)
