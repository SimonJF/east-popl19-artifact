let () = Foobarlib.foo ()
