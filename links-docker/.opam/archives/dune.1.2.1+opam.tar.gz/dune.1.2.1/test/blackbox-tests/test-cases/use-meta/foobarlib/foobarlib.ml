open! Str

let foo () =
  print_endline "foobarlib"
