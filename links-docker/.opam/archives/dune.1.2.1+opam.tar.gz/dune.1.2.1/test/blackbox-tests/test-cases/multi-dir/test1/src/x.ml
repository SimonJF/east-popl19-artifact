let x = Y.x ^ Z.x
