let x = Generated.x ^ Blah.x
