ignore Foo.linkme
