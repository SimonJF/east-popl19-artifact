#include <caml/mlvalues.h>

CAMLprim value test()
{
  return Val_unit;
}
