jbuilder has been renamed to dune. Refer to the manual for details of the
migration:

[manual](http://dune.readthedocs.io/en/latest/migration.html).
