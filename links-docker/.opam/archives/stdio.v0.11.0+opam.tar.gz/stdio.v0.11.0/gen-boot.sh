#!/bin/bash

exec ../base/gen-boot.sh stdio
