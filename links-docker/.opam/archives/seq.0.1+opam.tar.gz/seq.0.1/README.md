# Seq

Compatibility package for OCaml's standard iterator type starting from 4.07.

License: GPL
