include Core

module Emacs = Emacs
module Glob = Glob
module Perl = Perl
module Pcre = Pcre
module Posix = Posix
module Str = Str
