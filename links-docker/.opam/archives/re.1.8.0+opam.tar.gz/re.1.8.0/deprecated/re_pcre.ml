[@@@deprecated "Use Re.Pcre"]

include Re.Pcre
