let _ =
  {quote|
    let x = 5 in
    ()
  |quote}
