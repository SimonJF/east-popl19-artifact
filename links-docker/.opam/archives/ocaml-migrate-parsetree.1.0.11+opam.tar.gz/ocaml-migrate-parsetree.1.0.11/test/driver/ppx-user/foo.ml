let () =
  Printf.printf "%d\n%s\n%s\n"
    [%forty_two] [%cmd_line_arg] [%plop]
