0.8 — 2017-11-08
----------------

- Only use escape sequences or Windows calls when the stdout or stderr
  is a TTY. (issue #1).
- Port to jbuilder


